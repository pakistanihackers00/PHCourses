# Hello World Program:
clear
./extra_files/reading_files_pre.sh
    cat reading_files/re_fi_0.txt
    echo
./extra_files/example_struct_pre.sh
echo -e "\n\033[37;4;1m0: Hello World Program.\033[0m"
    ./extra_files/equal_line.sh
    echo -e "\033[35;1mCode:\033[0m"
    c++ extra_files/example_struct_desighn_start.cpp
    ./a.out
    cat example_struct/ex_st_0.txt
    c++ extra_files/example_struct_desighn_end.cpp
    ./a.out
    echo
    ./extra_files/equal_line.sh
    echo -e "\033[35;1mOutput:\033[0m"

    
        echo 1: "Hello World!"              
        echo 2: 'Hello world!'
        echo 3: Hello World!
        echo 

    ./extra_files/read_again.sh