#7: For Loops.   
    
    
    echo -e "\t\n\n\033[30;41mFor Loops..\033[0m\n"
    echo "------------------------------------------------------"
    echo -e "[ I ]:   \033[36mDemo of First Method.\033[0m"
    echo -e "[ II ]:  \033[36mDemo of Second Method.\033[0m"
    echo -e "[ III ]: \033[36mDemo of 3rd Method.\033[0m"
    echo -e "[ IV ]:  \033[36mDemo of 4th Method.\033[0m"
    echo -e "[ e ]:   \033[36mExit from this topic!\033[0m"
    echo "------------------------------------------------------"