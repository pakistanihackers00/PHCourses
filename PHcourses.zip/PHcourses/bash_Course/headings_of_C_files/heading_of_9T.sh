#Demo 0f Arrays.    
    echo -e "\n\033[30;41mDemo of Array.\033[0m\n"
    echo "-----------------------------------------------------------------------------------"
    echo -e "[ i ]:   \033[36mPrint out array in multiple ways.\033[0m"
    echo -e "[ ii ]:  \033[36mDeclaration a array through \"-a\" flag is a input.\033[0m"
    echo -e "[ e ]:   \033[36mExit from this topic!\033[0m"
    echo "-----------------------------------------------------------------------------------"