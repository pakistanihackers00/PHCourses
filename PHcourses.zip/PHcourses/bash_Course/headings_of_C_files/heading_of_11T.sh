#3: About Functions/Methods.   
    echo -e "\t\n\n\033[30;41mDemo of Functions/Methods.\033[0m\n"
    echo "---------------------------------------------------------------------------------"
    echo -e "[ i ]:   \033[36mDemo of First form of Function/Method declaration.\033[0m"
    echo -e "[ ii ]:  \033[36mDemo of Second form of Function/Method declaration.\033[0m"
    echo -e "[ iii ]:  \033[36mPassing parameter/arguments in Function/Method.\033[0m"
    echo -e "[ e ]:   \033[36mExit from this topic!\033[0m"
    echo "---------------------------------------------------------------------------------"
