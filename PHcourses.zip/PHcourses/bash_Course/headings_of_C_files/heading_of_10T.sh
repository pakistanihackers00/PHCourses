#8: About files.
    clear
    ./extra_files/reading_files_pre.sh
    echo -e "\t\n\n\033[30;41mDemo of Managing of Files.\033[0m\n"
    echo "----------------------------------------------------------------------------------------------------"
    echo -e "[ i ]:   \033[36mSome tricks of file.\033[0m"
    echo -e "[ ii ]:  \033[36mRead a file through while loop 1st Method.\033[0m"
    echo -e "[ iii ]: \033[36mRead a file through while loop 2nd Method.\033[0m"
    echo -e "[ iv ]:  \033[36mRead a file through while loop + IFS(internal feel separator) 3rd Method.\033[0m"
    echo -e "[ e ]:   \033[36mExit from this topic!\033[0m"
    echo "----------------------------------------------------------------------------------------------------"