#7: Arithematic in shell script.   
    echo -e "\t\n\n\033[30;41mDemo of Arithematic Operation.\033[0m\n"
    echo "------------------------------------------------------------------------"
    echo -e "[ i ]:   \033[36mDemo of First Method.\033[0m"
    echo -e "[ ii ]:  \033[36mDemo of Second Method.\033[0m"
    echo -e "[ iii ]: \033[36mDemo of basic Arithematic Calculation.\033[0m"
    echo -e "[ e ]:   \033[36mExit from this topic!\033[0m"
    echo "------------------------------------------------------------------------"