    #5: Conditional Operations.
        echo -e "\t\n\n\033[30;41mDemo of Conditional Operations.\033[0m\n"
        echo "-----------------------------------------------------------------------------------------"
        echo -e "[ i ]:   \033[36mDemo of IF Statement.\033[0m"
        echo -e "[ ii ]:  \033[36mDemo of Case Conditional with strict pattern..\033[0m"
        echo -e "[ iii ]: \033[36mDemo of Case Conditional withregular expression pattern..\033[0m"
        echo -e "[ iv ]:  \033[36mDemo of Select Conditional Operator.\033[0m"
        echo -e "[ e ]:   \033[36mExit from this topic!\033[0m"
        echo "-----------------------------------------------------------------------------------------"