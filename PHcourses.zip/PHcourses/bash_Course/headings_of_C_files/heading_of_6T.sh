    #6: Logic Operations
        echo -e "\t\n\n\033[30;41mDemo of Logic Operation.\033[0m\n"
        echo "------------------------------------------------------------"
        echo -e "[ i ]:   \033[36mDemo of AND Logic Operator.\033[0m"
        echo -e "[ ii ]:  \033[36mDemo of OR Logic Operator.\033[0m"
        echo -e "[ e ]:   \033[36mExit from this topic!\033[0m"
        echo "-------------------------------------------------------------"