#3: We can also give some input from user through "read" command, like :    

clear
    ./extra_files/reading_files_pre.sh
    echo -e "\t\n\n\033[30;41mDemo of User Input.\033[0m\n"
    echo "----------------------------------------------------------------------------------------------------"
    echo -e "[ i ]:   \033[36mDemo of input.\033[0m"
    echo -e "[ ii ]:  \033[36mGive input in same line.\033[0m"
    echo -e "[ iii ]: \033[36mDeclaration a array through '-a' flag.\033[0m"
    echo -e "[ iv ]:  \033[36mBy default 'read' save input in 'REPLY' variable if we didn't give variable.\033[0m"
    echo -e "[ e ]:   \033[36mExit from this topic!\033[0m"
    echo "----------------------------------------------------------------------------------------------------"
