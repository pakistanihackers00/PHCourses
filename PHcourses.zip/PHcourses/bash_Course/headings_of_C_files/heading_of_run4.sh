    #4: We can also pass some argument in the time of executing the our shell script, like:
        echo -e "\t\n\n\033[30;41mDemo of Arguments.\033[0m\n"
        echo "---------------------------------------------------------------------------------------------------------------------"
        echo -e "[ i ]:   \033[36mDemo of arguments.\033[0m"
        echo -e "[ ii ]:  \033[36mSaving argument in array.\033[0m"
        echo -e "[ iii ]: \033[36mShow arguments directly and also show number of arguments that how much arguments are there.\033[0m"
        echo -e "[ e ]:   \033[36mExit from this topic!\033[0m"
        echo "---------------------------------------------------------------------------------------------------------------------"