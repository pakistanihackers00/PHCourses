echo -e "\033[1;34m"
figlet Read file
echo -e "\033[0m"