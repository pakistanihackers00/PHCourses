echo -e "\033[1;37m"
figlet Example
echo -e "\033[0m"