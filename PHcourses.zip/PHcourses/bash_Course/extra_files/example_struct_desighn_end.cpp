#include<iostream>
using namespace std;
int main(){
    cout<<"\033[0m";
    return 0;
}