#include<iostream>
using namespace std;
int main(){
    cout<<"\033[33;3m";
    return 0;
}